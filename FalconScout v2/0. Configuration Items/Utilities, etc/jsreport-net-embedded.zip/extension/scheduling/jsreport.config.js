﻿module.exports = {
  "name": "scheduling",
  "main": "lib/scheduling.js",
  "dependencies": ["templates", "reports"]
}