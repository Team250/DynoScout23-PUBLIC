﻿module.exports = {
  "name": "embedding",
  "main": "lib/embedding.js",
  "hasPublicPart": false,
  "dependencies": [ "templates", "scripts", "data", "phantom-pdf", "html" ]
}