﻿module.exports = {
  "name": "authorization",
  "main": "lib/authorization.js",
  "hasPublicPart": false,
  "dependencies": [ "templates", "scripts", "data", "phantom-pdf", "html" ]
}