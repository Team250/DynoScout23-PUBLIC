﻿module.exports = {
  "name": "authentication",
  "main": "lib/authentication.js",
  "hasPublicPart": false,
  "dependencies": []
}