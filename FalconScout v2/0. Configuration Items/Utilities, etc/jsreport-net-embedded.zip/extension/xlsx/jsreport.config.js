﻿module.exports = {
  "name": "xlsx",
  "main": "lib/xlsx.js",
  "hasPublicPart": false
}