module.exports = {
    "name": "sharepoint",
    "main": "lib/sharepoint.js",
    "dependencies": [ "templates", "scripts", "data" ],
    "hasPublicPart": false
}